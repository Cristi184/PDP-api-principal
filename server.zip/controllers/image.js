
const ImageSchema = require("../models/Image")
const multer = require("multer");


const Storage = multer.diskStorage({
    destination: 'uploads',
    filename: (req, file, cb) => {
        cb(null, file.originalname);
    }
})

const image = multer({
    storage: Storage
}).single('testImage')

const uploadImage = async (req, res, next) => {
    image(req, res, (err) => {
        if (err) {
            console.log(err)
        } else {
            const newImage = new ImageSchema.ImageSchema({
                name: req.body.name,
                image: {
                    data: req.file.filename,
                    contentType: 'image/png'
                }
            })
            try {
                newImage.save()
                res.send('succesfully uploader')
            } catch (err) {
                console.log(err)
            }
        }
    })
};

const getImages = async (req, res, next) => {
    const allData = await ImageSchema.ImageSchema.find()
    res.json(allData)
};


module.exports = {getImages, uploadImage}