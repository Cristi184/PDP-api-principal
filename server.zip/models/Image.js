const mongoose = require('mongoose');

const ImageSchema = new mongoose.Schema({
    name: {
        type: String,
        require: true,
    },
    image: {
        data: Buffer,
        contentType: String
    }

}, {timestamps: true});

module.exports = {ImageSchema:mongoose.model("Image", ImageSchema)}